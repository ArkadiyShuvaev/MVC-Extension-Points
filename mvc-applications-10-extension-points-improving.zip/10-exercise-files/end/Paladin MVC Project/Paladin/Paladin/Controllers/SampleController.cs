﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Paladin.Controllers
{
    public class SampleController
    {
    }
}