﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Paladin.Models
{
    public class Progress
    {
        public int CurrentStage { get; set; }
        public int HighestStage { get; set; }
    }
}